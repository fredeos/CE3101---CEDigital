using backend.services.connections;

namespace backend.services {
    public class CEDigitalService {
        public SQLContext? sql_db = null;
        public MongoContext? mongo_db = null;
    }
}